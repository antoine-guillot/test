#include <QCoreApplication>
#include <iostream>
#include <string>
#include <fstream>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    std::ifstream fic("C:/Users/adm-ext-rollandg/Documents/S2/TestS2/Test_lecture_fichier_reverse/lecture_fichier_reverse/fichier_test.txt");
    if (fic)
    {
        fic.seekg(0, std::ios::end); // on se place a la fin du fichier ex:498
        //fic.seekg(-20, std::ios::cur);
        std::string line;
        std::cout<<fic.tellg()<<std::endl;
        //getline(fic,line);
        //unsigned int pos_fic=fic.tellg();
        unsigned int reverse_curs=0;
        while (line.find("<version>")==std::string::npos)
        {
            fic.seekg(reverse_curs, std::ios::cur);
            getline(fic,line);
            reverse_curs-=1;
            //std::cout<<line<<std::endl;
            std::cout<<fic.tellg()<<std::endl;
        }
        //fic.seekg(-1, std::ios::cur);
        //getline(fic,line);
        //if (line!="<version>") std::cout<< "no matches" << std::endl;
        std::cout<<fic.tellg()<<std::endl;
        std::cout<<reverse_curs<<std::endl;
        std::cout<<line<<std::endl;
        return 0;
    }
    else {std::cout <<"ERREUR de la lecture du fichier pour recuperer sa version" << std::endl; return 1;}
    return a.exec();
}
