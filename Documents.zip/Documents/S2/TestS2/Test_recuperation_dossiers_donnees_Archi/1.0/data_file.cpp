#include "data_file.h"


/* *** Constructeurs *** */


Data_file::Data_file()
{
    this->m_id = "";
    this->m_name = "";
    this->m_doc = "";
    this->m_property = {"",""};
    this->m_file_path = "";
}

Data_file::Data_file(std::string file_path)
{
    this->m_id = "";
    this->m_name = "";
    this->m_doc = "";
    this->m_property = {"",""};
    this->m_file_path = file_path;
}

Data_file::Data_file(std::string name, std::string id, std::string doc, std::pair<std::string,std::string> property, std::string file_path)
{
    this->m_id = name;
    this->m_name = id;
    this->m_doc = doc;
    this->m_property = property;
    this->m_file_path = file_path;
}


/* *** Setteurs, Getteurs *** */

void Data_file::set_m_name(const std::string name)
{
    this->m_name = name;
}

std::string Data_file::get_m_name() const
{
    return this->m_name;
}

void Data_file::set_m_id(const std::string id)
{
    this->m_id = id;
}

std::string Data_file::get_m_id() const
{
    return this->m_id;
}

void Data_file::set_m_doc(const std::string doc)
{
    this->m_doc = doc;
}

std::string Data_file::get_m_doc() const
{
    return this->m_doc;
}

void Data_file::set_m_property(const std::pair<std::string, std::string> property)
{
    this->m_property = property;
}

std::pair<std::string,std::string> Data_file::get_m_property() const
{
    return this->m_property;
}

void Data_file::set_m_file_path(const std::string file_path)
{
    this->m_file_path = file_path;
}

std::string Data_file::get_m_file_path() const
{
    return this->m_file_path;
}


/* *** Fonctions *** */


int Data_file::find_datas_of_file()
{
    std::ifstream fic(this->m_file_path);
    if (fic)
    {
        //std::vector<std::string> datas; //vecteur qui contiendra nos 4 champs obligatoires (name, id, documentation, property)
        std::string line; //une ligne du fichier de test

        //chaque flag pour securiser nos 4 champs
        //exemple: si le nom du champ "name=" se trouve dans l'id on empeche l'accès au vector car on ne prend que le premier match obtenu
        //flag_property maybe inutile ?
        bool flag_name(false), flag_id(false), flag_doc_opened(false), flag_doc_closed(false), flag_property(false);

        //securite pour le champ property, selon sa cle et la valeur de la cle
        bool flag_key(false), flag_value(false);

        while (getline(fic, line)) //on lit tout le fichier ligne par ligne
        {
            if (line.find("name=")!=std::string::npos && flag_name!=true) //npos signifie "no matches"
            {
                const auto pos_name(line.find("name="));
                const auto pos_sans_name=pos_name+6; //+6 pour 6 caractere a ignorer pour la valeur finale (name=")
                line=line.substr(pos_sans_name);
                line=line.substr(0,line.size()-1); //on enleve le dernier caractere qui est le guillemet fermant la chaine de la donnee
                this->m_name=line;
                flag_name=true;
            }
            else if (line.find("id=")!=std::string::npos && flag_id!=true)
            {
                const auto pos_id(line.find("id="));
                const auto pos_sans_id=pos_id+4; //+4 pour 4 caractere a ignorer pour la valeur finale (id=")
                line=line.substr(pos_sans_id);
                line=line.substr(0,line.size()-3); //on enleve les 3 derniers caracteres : guillemet fermant la chaine de la donnee et balise fermante ("/>)
                this->m_id=line;
                flag_id=true;
            }
            else if (line.find("<documentation>")!=std::string::npos && flag_doc_opened!=true)
            {
                const auto pos_doc_opened(line.find("<documentation>")); //position de <documentation> dans la ligne
                const auto pos_sans_doc=pos_doc_opened+15; //pos_sans_doc est la position de la chaine <documentation> qui est a ignorer pour la valeur finale
                flag_doc_opened=true;

                if (line.find("</documentation>")!=std::string::npos) //cas ou la documentation ne fait qu'une seule ligne du fichier
                    {
                        line=line.substr(pos_sans_doc);
                        const auto pos_doc_closed(line.find("</documentation>")); //position de </documentation> dans la nouvelle ligne tronquee
                        line=line.substr(0, pos_doc_closed);
                        this->m_doc=line;

                        flag_doc_closed=true;
                    }
                else //cas ou la documentation fait plusieurs lignes dans le fichier , notamment a cause des retour a la ligne
                    {
                        line=line.substr(pos_sans_doc);
                        this->m_doc=line;
                    }
            }
            else if (flag_doc_opened==true && flag_doc_closed==false)
            {
                if (line=="</documentation>")
                {
                    flag_doc_closed=true;
                    continue;
                }
                else
                {
                this->m_doc+=("\n" + line); //on ajoute au documentation l'interieur de la balise documentation en plus puis
                                                 //on rajoute les retour a la ligne de la documentation qui manque dans la ligne obtenue
                }
            }
            else if (line.find("<property")!=std::string::npos && flag_property!=true) //lit la donnee property meme sans une documentation anterieure
            {
                const auto pos_key(line.find("key="));
                const auto pos_sans_key=pos_key+5; //+5 pour 5 caracteres a ignorer pour la valeur de key dans property (key=")
                const auto pos_value=line.find("value=");
                const auto pos_sans_value=pos_value+7; //+7 pour 7 caracteres a ignorer pour la valeur de value dans property (value=")

                std::string line_value(line);

                std::string key="";
                for (unsigned int i(pos_sans_key);i<pos_value-2;i++) key+=line[i];
                this->m_property.first=key;

                line_value=line.substr(pos_sans_value);

                line_value=line_value.substr(0, line_value.size()-3); //on enleve les 3 derniers caracteres : balise fermante et guillemet fermant ("/>)
                this->m_property.second=line_value;

                flag_property=true;

            }
        }
    }
    else {std::cout << "Erreur analyse du fichier " << this->m_file_path << "..." << std::endl; return 1;}
    return 0;
}

void Data_file::print_datas() const
{
    std::cout<< "name => " << this->m_name << std::endl;
    std::cout<< "id => " << this->m_id << std::endl;
    std::cout<< "doc => " << this->m_doc << std::endl;
    std::cout<< "property => " << "cle=" << this->m_property.first << " et valeur=" << this->m_property.second << std::endl;
}
