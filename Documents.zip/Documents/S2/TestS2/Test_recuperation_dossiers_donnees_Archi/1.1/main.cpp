#include <QCoreApplication>
#include <QDebug>
#include <QDir>
#include <QString>

#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>

#include "data_file.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    clock_t t1,t2;
    t1=clock();
    for (unsigned int i(0);i<1;i++)
    {
    //QString chemin_archi_model="C:/Users/adm-ext-rollandg/Desktop/Archi/Collaboration/projetCollab/model";
    QString chemin_archi_model="C:/Users/adm-ext-rollandg/Documents/S2/Exemples_donnees/Exemple_Donnees_Archi_creees/model";

    QStringList Archi_folders_list({"/application/", "/business/", "/diagrams/", "/implementation_migration/", "/motivation/", "/other/", "/relations/", "/strategy/", "/technology/"});

    for (auto folder : Archi_folders_list) //pour chaque dossier obligatoire de Archi
    {
        QDir dir(chemin_archi_model+folder);
        dir.setFilter(QDir::Files); //On ne prends que les fichiers du repertoire (pas les fichiers cachees ni les sous-repertoires)
        QStringList file_list = dir.entryList(); //liste des noms de fichiers du dossier dir

        for (auto file : file_list) //pour chaque fichier dans le dossier
        {
                if (file!="folder.xml")
                {
                    Data_file data_file_exemples((chemin_archi_model+folder+file).toStdString());
                    data_file_exemples.find_datas_of_file();
                    std::cout << "Donnees du fichier " << data_file_exemples.get_m_file_path() << std::endl;
                    std::cout << std::endl;
                    data_file_exemples.print_datas();
                    std::cout << std::endl;
                }
        }
   }
   }
    t2=clock();
    std::cout << (float)(t2-t1)/CLOCKS_PER_SEC << std::endl;
    return a.exec();
}
