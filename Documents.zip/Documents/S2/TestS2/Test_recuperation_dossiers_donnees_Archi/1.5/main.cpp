#include <QCoreApplication>
#include <QDebug>
#include <QDir>
#include <QString>

#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>

#include "data_file.h"

//recuperer le version d'un fichier texte donne en parametre
/*unsigned int recup_version(std::string chemin_fic)
{
    std::ifstream fic(chemin_fic.c_str());
    if (fic)
    {
        fic.seekg(0, std::ios::end); // on se place a la fin du fichier
        std::string line;
        getline(fic,line);
        //fic.seekg(-line.size(), std::ios::cur);
        std::cout<<fic.tellg()<<std::endl;
        return 0;
    }
    else {std::cout <<"ERREUR de la lecture du fichier pour ecuperer sa version" << std::endl; return 1;}
}*/


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    clock_t t1,t2;
    t1=clock();
    for (unsigned int i(0);i<1;i++)
    {
    //QString chemin_archi_model="C:/Users/adm-ext-rollandg/Desktop/Archi/Collaboration/projetCollab/model";
    QString chemin_archi_model="C:/Users/adm-ext-rollandg/Documents/S2/Exemples_donnees/Exemple_Donnees_Properties/model";

    QStringList Archi_folders_list({"/application/", "/business/", "/diagrams/", "/implementation_migration/", "/motivation/", "/other/", "/relations/", "/strategy/", "/technology/"});

    QDir dir_appli;
    QString chemin_relatif=dir_appli.absolutePath();
    if (!(dir_appli.mkpath(chemin_relatif+"/Donnees_BD")))
        std::cout << "ERREUR : impossible de creer le repertoire " + chemin_relatif.toStdString() + "/Donnees_BD" << std::endl;

    for (auto folder : Archi_folders_list) //pour chaque dossier obligatoire de Archi
    {
        QDir dir(chemin_archi_model+folder);
        dir.setFilter(QDir::Files); //On ne prends que les fichiers du repertoire (pas les fichiers cachees ni les sous-repertoires)
        QStringList file_list = dir.entryList(); //liste des noms de fichiers du dossier dir

        for (auto file : file_list) //pour chaque fichier dans le dossier
        {
                if (file!="folder.xml")
                {
                    std::string const nom=file.split('.')[0].toStdString(); //nom du fichier sans l'extension pour la BD
                    std::string const nomFichier = "Donnees_BD/"+nom+".txt"; //nom complet du fichier a completer avec les donnees

                    unsigned int num_version=1; //version du fichier file
                    std::string line;
                    //std::cout << "Donnees du fichier " << (chemin_archi_model+folder+file).toStdString() << std::endl;
                    Data_file data_file_exemples((chemin_archi_model+folder+file).toStdString());
                    data_file_exemples.find_datas_of_file();
                    //data_file_exemples.print_datas();

                    std::ifstream flux_nomFichier_r((nomFichier).c_str());

                    //on recupere la version du fichier
                    while (getline(flux_nomFichier_r, line))
                    {
                        if (line.find("<version>")!=std::string::npos) num_version++;
                        //else num_version=1;
                    }

                    std::ofstream flux_nomFichier_w((nomFichier).c_str(), std::ios::app); //app pour append = ecrire a la fin du fichier sans le supprimer

                    if (flux_nomFichier_w)
                    {
                        //on ecrit dans le fichier file
                        flux_nomFichier_w<<"<version>" << num_version << std::endl;
                        flux_nomFichier_w<<"name="<<data_file_exemples.get_m_name()<<std::endl;
                        flux_nomFichier_w<<"id="<<data_file_exemples.get_m_id()<<std::endl;
                        flux_nomFichier_w<<"documentation="<<data_file_exemples.get_m_doc()<<std::endl;
                        for (auto p : data_file_exemples.get_m_properties()) flux_nomFichier_w << "properties=" << "<" << p.first << "," << p.second << ">" << std::endl;
                    }
                    else std::cout<<"ERREUR : impossible d'ecrire dans le fichier "+nomFichier<<std::endl;
                }
        }
   }
   }
    t2=clock();
    std::cout << (float)(t2-t1)/CLOCKS_PER_SEC << std::endl;
    return a.exec();
}
