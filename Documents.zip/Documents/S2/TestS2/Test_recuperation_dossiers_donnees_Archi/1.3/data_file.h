#ifndef DATA_FILE_H
#define DATA_FILE_H

#include <iostream>
#include <fstream>
#include <vector>

class Data_file
{
public:
    //Constructeurs
    Data_file();
    Data_file(std::string file_path);
    Data_file(std::string name, std::string id, std::string doc, std::vector<std::pair<std::string,std::string>> property, std::string file_path, unsigned int nb_version);

    //Setteurs, Getteurs
    void set_m_name(const std::string name);
    std::string get_m_name() const;

    void set_m_id(const std::string id);
    std::string get_m_id() const;

    void set_m_doc(const std::string doc);
    std::string get_m_doc() const;

    void set_m_property(const std::vector<std::pair<std::string,std::string>> property);
    std::vector<std::pair<std::string,std::string>> get_m_property() const;

    void set_m_file_path(const std::string file_path);
    std::string get_m_file_path() const;

    void set_m_nb_version(const unsigned int nb_version);
    unsigned int get_m_nb_version() const;

    //Fonctions
    int find_datas_of_file();
    void print_datas() const;

private:
    std::string m_name;
    std::string m_id;
    std::string m_doc;
    std::vector<std::pair<std::string,std::string>> m_property;
    std::string m_file_path;
    unsigned int m_nb_version;
};

#endif // DATA_FILE_H
