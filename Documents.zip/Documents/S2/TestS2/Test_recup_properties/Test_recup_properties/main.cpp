#include <QCoreApplication>
#include <iostream>
#include <string>
#include <fstream>



int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    std::vector<std::pair<std::string,std::string>> m_properties;

    std::ifstream fic("BusinessActor_a31e19a0-a369-4458-ad90-d97c513c3454.xml");
    if (fic)
    {
        std::string line;
        unsigned int num_property=-1;
        bool flag_properties(false);
        std::string key;
        std::string value;

        while (getline(fic, line)) //on lit tout le fichier ligne par ligne
        {
            if (line.find("<properties")!=std::string::npos && (flag_properties==false))
            {
                m_properties.push_back({"",""});
                num_property++;
                flag_properties=true;
            }
            else if (flag_properties==true)
            {
                if (line.find("key")!=std::string::npos)
                {
                    const auto pos_key(line.find("key="));
                    const auto pos_sans_key=pos_key+5; //+5 pour 5 caracteres a ignorer pour la valeur de key dans property (key=")

                    std::string key;
                    key=line.substr(pos_sans_key);
                    key=key.substr(0, key.size()-1); //on enleve la caractere " dans le champ key
                    m_properties[num_property].first=key;

                }
                else if (line.find("value")!=std::string::npos)
                {
                    const auto pos_value(line.find("value="));
                    const auto pos_sans_value=pos_value+7; //+7 pour 7 caracteres a ignorer pour la valeur de key dans property (value=")

                    value=line.substr(pos_sans_value);
                    value=value.substr(0, value.size()-3); //on enleve les 3 derniers caracteres : balise fermante et guillemet fermant ("/>)
                    m_properties[num_property].second=value;
                    flag_properties=false;
                }
            }
        }

    }
    else std::cout << "ERREUR... "<<std::endl;
    for (auto p : m_properties) std::cout<<"<" + p.first + "," + p.second + ">"<< std::endl;
    return a.exec();
}
