#include <QCoreApplication>

#include <QFile>
#include <QDebug>
#include <QString>

#include <iostream>
#include <fstream>
#include <vector>


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

//    QFile fic("C:/Users/adm-ext-rollandg/Documents/S1/Exemples_donnees/BusinessActor_58b41043-cb96-4be5-a465-3e9e99235a95.xml");
//    fic.open(QIODevice::ReadOnly | QIODevice::Text);
//    QTextStream flux(&fic);

//    std::string line;
//    std::vector<std::string> datas(4);

//    while (! flux.atEnd())
//    {
//        line = flux.readLine();
//        line.
//    }


    std::ifstream fic("C:/Users/adm-ext-rollandg/Documents/S1/Exemples_donnees/BusinessActor_58b41043-cb96-4be5-a465-3e9e99235a95.xml");
    if (fic)
    {
        std::vector<std::string> datas(4);
        std::string line;
        unsigned int num_line(0);
        //bool doc_flag(false);


        while (getline(fic, line))
        {
            //if (line=="</documentation>") doc_flag=true;
            //if (num_line<2) continue;
            if (num_line==2)
            {
                auto pos(line.find("name"));
                line=line.substr(pos);
                datas.push_back(line);
//            }
//            else if (num_line==3)
//            {
//                auto pos(line.find("id"));
//                line=line.substr(pos);
//                datas.push_back(line);
//            }
//            else if (num_line==4)
//            {
//                auto pos(line.find("<documentation>"));
//                line=line.substr(pos);
//                datas.push_back(line);
//            }
//            else if (num_line>4)
//            {
//                if (doc_flag==false) datas[2]+=line;
//                else
//                {
//                    auto pos(line.find("<property"));
//                    line=line.substr(pos);
//                    datas.push_back(line);
//                }
            }
            num_line++;
        }
        //std::cout << datas[0] << std::endl;
        //for (auto l : datas) std::cout << l << std::endl;
    }
    else std::cout << "erreur fichier à lire" << std::endl;

    //for (auto l : datas) std::cout << l << std::endl;



        //for (auto l : lines) std::cout << l << std::endl;

//        std::string str = "texte a analyser pour le test";
//        auto pos1(str.find("pour"));
//        std::cout << pos1 << std::endl;
//        std::string str1 = str.substr(pos1);
//        std::cout << str1 << std::endl;
}
