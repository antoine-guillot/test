#include <iostream>
#include <fstream>
#include <vector>

#include <ctime>

using namespace std;

int main()
{
    //permet de recup de temps d execution du programme
    clock_t t1,t2;
    t1=clock();

    for (unsigned int i=0;i<10000000;i++){ //nombre de fichiers a analyser en sequentiel

        //chemin du fichier de test

        std::ifstream fic("C:/Users/adm-ext-rollandg/Documents/S1/Exemples_donnees/BusinessActor_58b41043-cb96-4be5-a465-3e9e99235a95.xml");
        //std::ifstream fic("C:/Users/adm-ext-rollandg/Documents/S1/Exemples_donnees/ArchimateDiagramModel_3f6e23b1-a0d3-4c4a-a0df-77868851b0a7.xml");
        if (fic)
        {
            std::vector<std::string> datas; //vecteur qui contiendra nos 4 champs obligatoires (name, id, documentation, property)
            std::string line; //une ligne du fichier de test

            //chaque flag pour securiser nos 4 champs
            //exemple: si le nom du champ "name=" se trouve dans l'id on empeche l'accès au vector car on ne prend que le premier match obtenu
            //flag_property maybe inutile ?
            bool flag_name(false), flag_id(false), flag_doc_opened(false), flag_doc_closed(false), flag_property(false);


            while (getline(fic, line)) //on lit tout le fichier ligne par ligne
            {
                if (line.find("name=")!=std::string::npos && flag_name!=true) //npos signifie "no matches"
                {
                    //std::cout << line << std::endl;
                    datas.push_back(line);
                    flag_name=true;
                }
                else if (line.find("id=")!=std::string::npos && flag_id!=true)
                {
                    //std::cout << line << std::endl;
                    datas.push_back(line);
                    flag_id=true;
                }
                else if (line.find("<documentation>")!=std::string::npos && flag_doc_opened!=true)
                {
                    //std::cout << line << std::endl;
                    datas.push_back(line);
                    flag_doc_opened=true;
                }
                else if (flag_doc_opened==true && flag_doc_closed==false)
                {
                    if (line=="</documentation>")
                    {
                        flag_doc_closed=true;
                        continue;
                    }
                    else
                    {
                    //std::cout << "interieur de doc :" << line << std::endl;
                    datas[2]+= ("\n" + line); //on ajoute au documentation l'interieur de la balise documentation en plus puis
                                              //on rajoute les retour a la ligne qui manque
                    }
                }
                else if (line.find("<property")!=std::string::npos && flag_property!=true && flag_doc_closed!=false)
                {
                    //std::cout << line << std::endl;
                    datas.push_back(line);
                    flag_property=true;
                }
            }
            for (auto l : datas) std::cout << l << std::endl;
        }
        else std::cout << "erreur fichier à lire" << std::endl;
        }

    t2=clock();
    std::cout << (float)(t2-t1)/CLOCKS_PER_SEC << std::endl;
    return 0;
}
