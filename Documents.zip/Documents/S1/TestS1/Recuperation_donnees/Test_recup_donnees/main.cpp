#include <iostream>
#include <fstream>
#include <vector>

int main()
{

    std::ifstream fic("C:/Users/adm-ext-rollandg/Documents/S1/Exemples_donnees/BusinessActor_58b41043-cb96-4be5-a465-3e9e99235a95.xml");
    if (fic)
    {
        std::string line;
        std::vector<std::string> lines;
//        getline(fic,line);
//        std::cout << line << std::endl;
        while (getline(fic, line))
        {
            lines.push_back(line);
        }
        auto pos(lines[2].find("name"));
        lines[2] = lines[2].substr(pos);
        std::cout <<lines[2] << std::endl;

        //for (auto l : lines) std::cout << l << std::endl;

//        std::string str = "texte a analyser pour le test";
//        auto pos1(str.find("pour"));
//        std::cout << pos1 << std::endl;
//        std::string str1 = str.substr(pos1);
//        std::cout << str1 << std::endl;

    }
    else std::cout << "erreur fichier à lire" << std::endl;
    return 0;
}
