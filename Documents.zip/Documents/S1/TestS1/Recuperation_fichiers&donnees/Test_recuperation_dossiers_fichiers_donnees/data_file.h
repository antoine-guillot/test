#ifndef DATA_FILE_H
#define DATA_FILE_H

#include <iostream>
#include <fstream>
#include <vector>

class Data_file
{
public:
    Data_file();
    Data_file(std::string file_path);
    Data_file(std::vector<std::string> datas, std::string file_path);

    int set_m_datas(const std::vector<std::string> datas);
    std::vector<std::string> get_m_datas() const;

    void set_m_file_path(const std::string file_path);
    std::string get_m_file_path() const;


    int find_datas_of_file();
    void print_datas() const;

private:
    std::vector<std::string> m_datas;
    std::string m_file_path;
};

#endif // DATA_FILE_H
