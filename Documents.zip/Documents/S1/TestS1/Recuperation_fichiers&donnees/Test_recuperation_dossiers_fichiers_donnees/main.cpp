#include <QCoreApplication>
#include <QDebug>
#include <QDir>
#include <QString>

#include <iostream>
#include <fstream>
#include <vector>

#include "data_file.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    //chemin du fichier de test
    //const std::string chemin_exemples("C:/Users/adm-ext-rollandg/Documents/S1/Exemples_donnees/");
    //std::string chemin_fic(chemin_exemples+"BusinessActor_58b41043-cb96-4be5-a465-3e9e99235a95.xml");
    //std::string chemin_fic(chemin_exemples+"BusinessActor_27066577-2933-43e5-9ba9-b0c1fdabb811.xml");
    //std::string chemin_fic(chemin_exemples+"FlowRelationship_6b6f916f-8137-46d0-bf76-9a41e45ae7ab.xml");
    //std::string chemin_fic(chemin_exemples+"ArchimateDiagramModel_3f6e23b1-a0d3-4c4a-a0df-77868851b0a7.xml");

    //Data_file data_Business_actor_1(chemin_fic);
    //data_Business_actor_1.find_datas_of_file();
    //data_Business_actor_1.print_datas();

    /* *** TEST QDIR *** */

    QString chemin_exemples="C:/Users/adm-ext-rollandg/Documents/S1/Exemples_donnees/";

    QDir dir(chemin_exemples);
    dir.setFilter(QDir::Files); //On ne prends que les fichiers du repertoire (pas les fichiers cachees ni les sous-repertoires)
    QStringList file_list = dir.entryList(); //liste des noms de fichiers du dossier dir

    for (auto file : file_list)
    {
        Data_file data_file_exemples((chemin_exemples+file).toStdString());
        data_file_exemples.find_datas_of_file();
        std::cout << "Donnees du fichier " << data_file_exemples.get_m_file_path() << std::endl;
        std::cout << std::endl;
        data_file_exemples.print_datas();
    }

    return a.exec();
}
