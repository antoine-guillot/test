#include "data_file.h"

Data_file::Data_file()
{
    this->m_datas={"","","",""};
    this->m_file_path = "";
}

Data_file::Data_file(std::string file_path)
{
    this->m_datas={"","","",""};
    this->m_file_path = file_path;
}

Data_file::Data_file(std::vector<std::string> datas, std::string file_path)
{
    this->m_datas = datas;
    this->m_file_path = file_path;
}

int Data_file::set_m_datas(const std::vector<std::string> datas)
{
    if (datas.size()==4) {this->m_datas = datas; return 0;}
    else return 1;
}

std::vector<std::string> Data_file::get_m_datas() const
{
    return this->m_datas;
}

void Data_file::set_m_file_path(const std::string file_path)
{
    this->m_file_path = file_path;
}

std::string Data_file::get_m_file_path() const
{
    return this->m_file_path;
}

int Data_file::find_datas_of_file()
{
    std::ifstream fic(this->m_file_path);
    if (fic)
    {
        //std::vector<std::string> datas; //vecteur qui contiendra nos 4 champs obligatoires (name, id, documentation, property)
        std::string line; //une ligne du fichier de test

        //chaque flag pour securiser nos 4 champs
        //exemple: si le nom du champ "name=" se trouve dans l'id on empeche l'accès au vector car on ne prend que le premier match obtenu
        //flag_property maybe inutile ?
        bool flag_name(false), flag_id(false), flag_doc_opened(false), flag_doc_closed(false), flag_property(false);

        while (getline(fic, line)) //on lit tout le fichier ligne par ligne
        {
            if (line.find("name=")!=std::string::npos && flag_name!=true) //npos signifie "no matches"
            {
                const auto pos_name(line.find("name="));
                const auto pos_sans_name=pos_name+6; //+6 pour 6 caractere a ignorer pour la valeur finale (name=")
                line=line.substr(pos_sans_name);
                line=line.substr(0,line.size()-1); //on enleve le dernier caractere qui est le guillemet fermant la chaine de la donnee
                this->m_datas[0]=line;
                flag_name=true;
            }
            else if (line.find("id=")!=std::string::npos && flag_id!=true)
            {
                const auto pos_name(line.find("id="));
                const auto pos_sans_id=pos_name+4; //+4 pour 4 caractere a ignorer pour la valeur finale (id=")
                line=line.substr(pos_sans_id);
                line=line.substr(0,line.size()-3); //on enleve les 3 derniers caracteres : guillemet fermant la chaine de la donnee et balise fermante ("/>)
                this->m_datas[1]=line;
                flag_id=true;
            }
            else if (line.find("<documentation>")!=std::string::npos && flag_doc_opened!=true)
            {
                const auto pos_doc_opened(line.find("<documentation>")); //position de <documentation> dans le ligne
                const auto pos_sans_doc=pos_doc_opened+15; //pos_sans_doc est la position de la chaine <documentation> qui est a ignorer pour la valeur finale
                flag_doc_opened=true;

                if (line.find("</documentation>")!=std::string::npos) //cas ou la documentation ne fait qu'une seule ligne du fichier
                    {
                        line=line.substr(pos_sans_doc);
                        const auto pos_doc_closed(line.find("</documentation>")); //position de </documentation> dans la nouvelle ligne tronquee
                        line=line.substr(0, pos_doc_closed);
                        this->m_datas[2]=line;

                        flag_doc_closed=true;
                    }
                else //cas ou la documentation fait plusieurs lignes dans le fichier , notamment a cause des retour a la ligne
                    {
                        line=line.substr(pos_sans_doc);
                        this->m_datas[2]=line;
                    }
            }
            else if (flag_doc_opened==true && flag_doc_closed==false)
            {
                if (line=="</documentation>")
                {
                    flag_doc_closed=true;
                    continue;
                }
                else
                {
                this->m_datas[2]+=("\n" + line); //on ajoute au documentation l'interieur de la balise documentation en plus puis
                                                 //on rajoute les retour a la ligne de la documentation qui manque dans la ligne obtenue
                }
            }
            else if (line.find("<property")!=std::string::npos && flag_property!=true && flag_doc_closed!=false)
            {
                this->m_datas[3]=line;
                flag_property=true;
            }
        }
    }
    else {std::cout << "Erreur analyse du fichier " << this->m_file_path << "..." << std::endl; return 1;}
    return 0;
}

void Data_file::print_datas() const
{
    for (auto d : this->m_datas) std::cout << d << std::endl;
}
