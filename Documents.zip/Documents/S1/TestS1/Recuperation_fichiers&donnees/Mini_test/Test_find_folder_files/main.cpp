#include <QCoreApplication>
#include <QDebug>
#include <QDir>
#include <QString>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QString chemin="C:/Users/adm-ext-rollandg/Documents/S1/Exemples_donnees/";
    QDir dir(chemin);
    dir.setFilter(QDir::Files);
    QStringList list_fichiers=dir.entryList();
    for (auto f : list_fichiers) qDebug()<<f;

    return a.exec();
}
