#include <QCoreApplication>
#include <QDebug>

#include <iostream>
#include <fstream>
#include <vector>

#include "data_file.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);


    //chemin du fichier de test

    //std::string chemin_fic("C:/Users/adm-ext-rollandg/Documents/S1/Exemples_donnees/BusinessActor_58b41043-cb96-4be5-a465-3e9e99235a95.xml");
    //std::string chemin_fic("C:/Users/adm-ext-rollandg/Documents/S1/Exemples_donnees/BusinessActor_27066577-2933-43e5-9ba9-b0c1fdabb811.xml");
    //std::string chemin_fic("C:/Users/adm-ext-rollandg/Documents/S1/Exemples_donnees/FlowRelationship_6b6f916f-8137-46d0-bf76-9a41e45ae7ab.xml");
    std::string chemin_fic("C:/Users/adm-ext-rollandg/Documents/S1/Exemples_donnees/ArchimateDiagramModel_3f6e23b1-a0d3-4c4a-a0df-77868851b0a7.xml");


    Data_file data_Business_actor_1(chemin_fic);

    data_Business_actor_1.find_datas_of_file();

    data_Business_actor_1.print_datas();


    return a.exec();
}
